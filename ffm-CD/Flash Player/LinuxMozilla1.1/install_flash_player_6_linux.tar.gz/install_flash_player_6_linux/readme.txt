Macromedia
Flash Player 6 for Linux
Mozilla Plug-in and Standalone players
9 December 2002


Macromedia is proud to release the Macromedia Flash Player 6 Mozilla Plug-in and Standalone players for
the Linux operating system.


Supported Distributions
-----------------------

- Flash Player 6 for Linux requires at a minimum glibc 2.2.x.  It
  should work on most flavors of RedHat 7.x and on RedHat 8.0; it is most extensively
  tested on RedHat 7.3 and RedHat 8.0.  Beta testers have tested on various flavors of Debian, Slackware,
  Mandrake and SUSE.

- Device fonts require outline fonts to be installed.  This is
  a change from Flash Player 5 for Linux.  Some fonts
  to install:

	ttfonts
	urw-fonts
	ttfonts-ja for Japanese device fonts
	ttfonts-ko for Korean device fonts
	ttfonts-zh_TW for traditional Chinese device fonts
	ttfonts-zh_CN for simplified Chinese device fonts


==========================================================================
Flash Player Platform  | Browser         | Reference       | Hardware    |
                       |                 | Implementation  |             |
--------------------------------------------------------------------------
Linux Mozilla Plugin   | Mozilla 1.x     | Linux RedHat 7.x| Intel x86 PC|
Linux Mozilla Plugin   | Netscape 7.x    | Linux RedHat 7.x| Intel x86 PC|
Linux Mozilla Plugin   | Opera 6.x       | Linux RedHat 7.x| Intel x86 PC|
Linux Mozilla Plugin   | Konqueror 3.0.3+| Linux RedHat 7.x| Intel x86 PC|
Linux Mozilla Plugin   | Galeon 1.2.4    | Linux RedHat 7.x| Intel x86 PC|
--------------------------------------------------------------------------
Linux Standalone       | n/a             | Linux RedHat 7.x| Intel x86 PC|
--------------------------------------------------------------------------

Note: Netscape 4.x is no longer supported.  The Flash Player will work
for many Flash movies but there are a lot of capabilities that are
broken.

Privacy
-------

Flash Player 6 for Linux will create a directory in ~/.macromedia for
local storage of shared objects.  The player also supports the Flash
MX camera and microphone capabilities.  If you are concerned about the
associated privacy issues please visit:

	http://www.macromedia.com/support/flashplayer/help/settings/
	http://www.macromedia.com/support/flashplayer/help/localinfo/


Installation
------------

To install the Plug-in Player for Linux:

- This installer is script-based and cannot be run from a GUI.
- Uncompress install_flash_player_6_linux.tar.gz.  A directory called install_flash_player_6_linux is created.  Navigate to this directory.
- From the command line, type ./flashplayer-installer to run the installer.  The installer will instruct you to shut down your browser(s).
- Once the installation is complete, the plug-in will be installed in your Mozilla browser.  To verify, choose Help > About Plug-ins from the browser's menu.

To install the Standalone Player for Linux:

- This installer is script-based and cannot be run from a GUI.
- Uncompress install_flash_player_6_linux_sa.tar.gz.  A directory called install_flash_player_6_linux_sa is created.  Navigate to this directory.
- From the command line, type ./flashplayer-installer to run the installer.  For root users, gflashplayer will be copied to /usr/bin. For non-root users, it will be copied to a folder named bin in your home directory.


Unistall instructions
---------------------

To remove the Plug-in Player for Linux:

For root users:
- Quit the browser.
- Navigate to the browser's plug-in directory (i.e. /usr/local/mozilla/plugins).
- Remove libflashplayer.so and flashplayer.xpt.

For non-root users:
- Quit the browser.
- Navigate to your home directory and locate the folder named .mozilla.
- From that folder, open the folder named plugin and remove libflashplayer.so, flashplayer.xpt and x-shockwave-flash.desktop.

To remove the Standalone Player for Linux:

For root users:
- Navigate to /usr/bin.
- Delete gflashplayer.

For non-root users:
- Navigate to your home directory and locate the folder named bin.
- Delete gflashplayer.


Optimal X Server Configuration
------------------------------

Flash Player should work with any X server configuration.  However,
optimal performance is achieved at the following color depths and
color mask settings:

         Depth: 8
        Visual: PseudoColor

         Depth: 15
Bits Per Pixel: 16
        Visual: TrueColor
      Red Mask: 0x00007C00
    Green Mask: 0x000003E0
     Blue Mask: 0x0000001F

         Depth: 16
Bits Per Pixel: 16
        Visual: TrueColor
      Red Mask: 0x0000F800
    Green Mask: 0x000007E0
     Blue Mask: 0x0000001F

         Depth: 24
Bits Per Pixel: 24
        Visual: TrueColor
      Red Mask: 0x00FF0000
    Green Mask: 0x0000FF00
     Blue Mask: 0x000000FF

         Depth: 32
Bits Per Pixel: 32
        Visual: TrueColor
      Red Mask: 0x00FF0000
    Green Mask: 0x0000FF00
     Blue Mask: 0x000000FF

         Depth: 32
Bits Per Pixel: 32
        Visual: TrueColor
      Red Mask: 0x000000FF
    Green Mask: 0x0000FF00
     Blue Mask: 0x00FF0000

In addition, the X server's image byte order must match the host byte
order in order to achieve optimal performance using one of the above
configurations.

Macromedia Flash Player takes advantage of the the MIT-SHM Shared Memory
Extension.  This will boost performance on supported systems.

Internationalization
--------------------

Flash Player 6 is internationalized for a number of languages.  Flash 
Player determines the language setting from the environment variable LANG.
If LANG is not set the players will default to English.

To set LANG in .bashrc:

	export LANG=spanish

or .cshrc

	setenv LANG es

These locales are currently recognized:

==========================================================================
Language     | Set LANG to            | Or                               |
--------------------------------------------------------------------------
English      | C,  LC, POSIX, english | en_*                             |
German       | de, deutsch, german    | de_*                             |
Spanish      | spanish                | es_*                             |
French       | fran�ais, french       | fr_BE, fr_CA, fr,FR, fr_LU       |
Italian      | italian                | it_IT, it_CH                     |
Swedish      | swedish                | sv_FI, sv_SE                     |
Portuguese   | portuguese             | pt_BR, pt_PT                     |
Japanese     | japanese               | ja_JP                            |
Korean       | korean                 | ko_KR                            |
Chinese Simp |  -                     | zh_CN                            |
Chinese Trad |  -                     | zh_TW                            |
--------------------------------------------------------------------------

To see the many options for en, de and es:

	locale -a | grep en
	locale -a | grep de
	locale -a | grep es


Known Bugs
----------

Both players:
Numerous problems running audio out and mic at the same time.
Alpha settings not correctly read.
Video and Audio get out of sync on long movies.
When mic is active and Settings panel is opened and Mic tab is selected, audio input becomes delayed and choppy.
Asian locale - Need to reset IME when user clicks on new text field.
Freetype version 2.0.9 is supported; version 2.1.3 or later not yet tested.
The isDown state of the Delete key on the keyboard does not register a True state when it is pressed.


Plug-in only:
Not able to copy text (and paste) from Flash to the Clipboard.
Ctrl+N doesn't work when Flash is playing in Mozilla browser.
Konqueror - BadWindow error on command line when closing a movie.
Mozilla - Audio not working correctly using browser tabs.
Mozilla - Windowless mode not implemented.
Chinese - some special characters aren't displayed correctly.
Opera - Blank context menu for Asian languages.
Not able to type or delete when cursor is outside of the movie's area.
Not able to type in text field when mouse over another swf.
Switching Japanese text input modes in an editable text field not working.


Standalone only:
GetURL mailto launches Konqueror and then external mail application at the same time.
Context and standalone menu not localized for LANG=zh_TW (Chinese Traditional) or LANG=ja_JP (Japanese) in a projector.
One mouseUp event is recognized every two mouseUp events.
getURL POST fails to open a browser window.
Japanese - "\r" character is not displayed.
French - high ascii character missing in Create Projector dialog bar: You see: "Crer projecteur" instead of "Cr�er projecteur".
Portuguese - Standalone Help menu name is higher than other menu items.
Chinese Simplified - "Selection" in File Open Sub Dialog should be localized.
Chinese - OK/Confirm button in About box is truncated.


Technical Issues and Reporting Bugs
-----------------------------------

The Webplayers Discussion Group provides an open forum to discuss 
technical issues regarding Macromedia Players. Also of interest are 
the Flash and Flash Site Design Discussion Groups. 
Macromedia Technical Support actively monitors these groups, as 
well as hosting a community of users there. Descriptions and links 
to these discussion groups can be found at: 
 
http://www.macromedia.com/support/forums/


Bug reports may be sent to flashplayerunix@macromedia.com 
To allow us to investigate reported bugs, please include the 
following information:

1) Platform and version
2) Browser version
3) Reproducible steps including a URL to the web site where the 
   problem was encountered.

If we need further information about a bug, you will be contacted.  An
automated reply will be sent to assure you that we have received your
bug report.  Due to the volume of mail received we are not able to
individually respond to each report.


